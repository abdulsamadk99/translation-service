<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class TranslationKeyFactory extends Factory
{
    public function definition(): array
    {
        return [
            'key' => 'app.' . $this->faker->unique()->word() . '.' . $this->faker->word(),
            'description' => $this->faker->sentence(),
        ];
    }
}
