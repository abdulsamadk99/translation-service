<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\TranslationKey;

class TranslationValueFactory extends Factory
{
    public function definition(): array
    {
        return [
            'translation_key_id' => TranslationKey::factory(),
            'locale' => $this->faker->randomElement(['en', 'fr', 'es']),
            'value' => $this->faker->sentence(),
            'is_active' => $this->faker->boolean(80),
        ];
    }
}
