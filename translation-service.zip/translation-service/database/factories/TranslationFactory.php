<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Translation>
 */
class TranslationFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
{
    return [
        'text' => $this->faker->sentence,
        'language' => $this->faker->randomElement(['en', 'ur', 'sd']),
        'user_id' => \App\Models\User::factory(),
    ];
}

}
