<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\TranslationKey;
use App\Models\TranslationValue;

class SeedTranslations extends Command
{
    protected $signature = 'translations:seed {count=100000}';
    protected $description = 'Seed translations data with given count';

    public function handle()
    {
        $count = (int) $this->argument('count');
        $batch = 1000;
        $locales = ['en', 'fr', 'es'];

        $this->info("Seeding $count translations...");

        for ($i = 0; $i < $count; $i += $batch) {
            $keys = [];
            for ($j = 0; $j < $batch; $j++) {
                $keys[] = [
                    'key' => 'key_' . ($i + $j),
                    'description' => 'Description ' . ($i + $j),
                    'created_at' => now(),
                    'updated_at' => now(),
                ];
            }
            TranslationKey::insert($keys);
            $inserted = TranslationKey::orderBy('id', 'desc')->take($batch)->pluck('id');

            $values = [];
            foreach ($inserted as $keyId) {
                foreach ($locales as $loc) {
                    $values[] = [
                        'translation_key_id' => $keyId,
                        'locale' => $loc,
                        'value' => "Value {$keyId}-$loc",
                        'is_active' => true,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ];
                }
            }
            TranslationValue::insert($values);

            $this->info("Seeded " . ($i + $batch));
        }

        $this->info("Done!");
    }
}
