<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TranslationValue extends Model
{
    protected $fillable = ['translation_key_id', 'locale', 'value', 'is_active'];

    public function key()
    {
        return $this->belongsTo(TranslationKey::class, 'translation_key_id');
    }
}
