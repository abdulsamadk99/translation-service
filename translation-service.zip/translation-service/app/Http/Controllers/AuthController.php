<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\ApiToken;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        if (!Auth::attempt($credentials)) {
            return response()->json(['error' => 'Invalid credentials'], 401);
        }

        $plain = bin2hex(random_bytes(32));

        $token = ApiToken::create([
            'user_id'    => Auth::id(),
            'name'       => 'default',
            'token_hash' => hash('sha256', $plain),
            'expires_at' => now()->addMonths(6),
        ]);

        return response()->json(['token' => $plain], 201);
    }

    public function logout(Request $request)
    {
        $header = $request->header('Authorization');
        if ($header && str_starts_with($header, 'Bearer ')) {
            $hash = hash('sha256', substr($header, 7));
            ApiToken::where('token_hash', $hash)->delete();
        }

        return response()->json(['message' => 'Logged out']);
    }
}
