<?php

namespace App\Http\Controllers;

use App\Models\TranslationKey;
use App\Models\TranslationValue;
use App\Models\Tag;
use Illuminate\Http\Request;

class TranslationController extends Controller
{
    public function store(Request $request)
    {
        $data = $request->validate([
            'key'         => 'required|string|regex:/^[a-z0-9._-]+$/|unique:translation_keys,key',
            'description' => 'nullable|string',
            'values'      => 'required|array',
            'values.*.locale' => 'required|string|max:10',
            'values.*.value'  => 'required|string',
            'tags'        => 'array',
        ]);

        $key = TranslationKey::create([
            'key' => $data['key'],
            'description' => $data['description'] ?? null,
        ]);

        foreach ($data['values'] as $val) {
            $key->values()->create([
                'locale'    => $val['locale'],
                'value'     => $val['value'],
                'is_active' => $val['is_active'] ?? true,
            ]);
        }

        if (!empty($data['tags'])) {
            $tagIds = collect($data['tags'])->map(function ($t) {
                return Tag::firstOrCreate(['name' => $t])->id;
            });
            $key->tags()->sync($tagIds);
        }

        return response()->json($key->load('values', 'tags'));
    }

    public function show(string $key)
    {
        $record = TranslationKey::with(['values', 'tags'])
            ->where('key', $key)
            ->firstOrFail();

        return response()->json($record);
    }

    public function update(Request $request, string $key)
    {
        $record = TranslationKey::where('key', $key)->firstOrFail();

        $data = $request->validate([
            'description' => 'nullable|string',
            'values'      => 'array',
            'tags'        => 'array',
        ]);

        if (isset($data['description'])) {
            $record->update(['description' => $data['description']]);
        }

        if (!empty($data['values'])) {
            foreach ($data['values'] as $val) {
                TranslationValue::updateOrCreate(
                    ['translation_key_id' => $record->id, 'locale' => $val['locale']],
                    ['value' => $val['value'], 'is_active' => $val['is_active'] ?? true]
                );
            }
        }

        if (!empty($data['tags'])) {
            $tagIds = collect($data['tags'])->map(fn($t) => Tag::firstOrCreate(['name' => $t])->id);
            $record->tags()->sync($tagIds);
        }

        return response()->json($record->load('values', 'tags'));
    }

    public function search(Request $request)
    {
        $q = $request->query('q');
        $tag = $request->query('tag');
        $locale = $request->query('locale');

        $query = TranslationKey::with(['values', 'tags']);

        if ($q) {
            $query->where('key', 'like', "%$q%")
                  ->orWhereHas('values', fn($q2) => $q2->where('value', 'like', "%$q%"));
        }

        if ($tag) {
            $query->whereHas('tags', fn($t) => $t->where('name', $tag));
        }

        if ($locale) {
            $query->whereHas('values', fn($q2) => $q2->where('locale', $locale));
        }

        return $query->paginate(20);
    }
}
