<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TranslationValue;

class ExportController extends Controller
{
    public function export(string $locale, Request $request)
    {
        $tags  = (array) $request->query('tags', []);
        $since = $request->query('since');

        $etagKey = 'exp:' . $locale . ':' . md5(json_encode($tags)) . ':' . optional(TranslationValue::max('updated_at'))->timestamp;
        $etag = '"' . $etagKey . '"';

        if ($request->header('If-None-Match') === $etag) {
            return response('', 304)->header('ETag', $etag);
        }

        $query = TranslationValue::query()
            ->join('translation_keys', 'translation_keys.id', '=', 'translation_values.translation_key_id')
            ->when($since, fn($q) => $q->where('translation_values.updated_at', '>=', $since))
            ->when($tags, function ($q) use ($tags) {
                $q->join('translation_key_tag', 'translation_key_tag.translation_key_id', '=', 'translation_keys.id')
                  ->join('tags', 'tags.id', '=', 'translation_key_tag.tag_id')
                  ->whereIn('tags.name', $tags);
            })
            ->where('translation_values.locale', $locale)
            ->where('translation_values.is_active', true)
            ->select('translation_keys.key', 'translation_values.value')
            ->orderBy('translation_keys.key');

        return response()->stream(function () use ($query) {
            echo "{";
            $first = true;
            $query->chunk(5000, function ($rows) use (&$first) {
                foreach ($rows as $r) {
                    if (!$first) echo ",";
                    echo json_encode($r->key) . ":" . json_encode($r->value);
                    $first = false;
                }
            });
            echo "}";
        }, 200, [
            'Content-Type' => 'application/json; charset=utf-8',
            'Cache-Control' => 'public, max-age=60',
            'ETag' => $etag,
        ]);
    }
}
