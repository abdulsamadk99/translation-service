<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\ApiToken;

class TokenAuthMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        $header = $request->header('Authorization');

        if (!$header || !str_starts_with($header, 'Bearer ')) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        $plain = substr($header, 7);
        $hash  = hash('sha256', $plain);

        $token = ApiToken::where('token_hash', $hash)->first();

        if (!$token || $token->isExpired()) {
            return response()->json(['error' => 'Invalid or expired token'], 401);
        }

        // update last_used_at
        $token->forceFill(['last_used_at' => now()])->save();

        auth()->login($token->user);

        return $next($request);
    }
}
