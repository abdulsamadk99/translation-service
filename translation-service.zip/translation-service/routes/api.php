<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\TranslationController;
use App\Http\Controllers\ExportController;

// Public routes (login, etc.)
Route::post('/login', [AuthController::class, 'login']);

// Protected routes (token required)
Route::middleware('token.auth')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);

    // Translations CRUD/Search
    Route::post('/translations', [TranslationController::class, 'store']);
    Route::patch('/translations/{key}', [TranslationController::class, 'update']);
    Route::get('/translations/{key}', [TranslationController::class, 'show']);
    Route::get('/translations', [TranslationController::class, 'search']);

    // Export translations
    Route::get('/export/{locale}', [ExportController::class, 'export']);

});

