<?php

namespace Tests\Unit; 

use Tests\TestCase;
use App\Models\User;
use App\Models\ApiToken;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ApiTokenTest extends TestCase
{
    use RefreshDatabase;
    public function test_api_token_expiration_works()
    {
        $user = User::factory()->create();

        $token = ApiToken::create([
            'user_id'    => $user->id,
            'name'       => 'test',
            'token_hash' => hash('sha256', 'dummy'),
            'expires_at' => now()->subDay(),
        ]);

        $this->assertTrue($token->isExpired());
    }
}
